package com.example.technicalassesment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewardPointsCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
